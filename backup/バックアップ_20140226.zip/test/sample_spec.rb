require 'rspec'

describe 'Sample' do
  it { expect(true).to be_true }
  it { expect(false).to be_false }
  it { expect(nil).to be_nil }
end
